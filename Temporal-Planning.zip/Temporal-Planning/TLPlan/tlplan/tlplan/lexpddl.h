/* lexpddl.h */

DECLSPEC void LoadPddlProblem
(
	char *psFile						/* file name */
);
